//
//  RBA_SDK-Swift.h
//
//  Created by Sergey Pjatkin on 1/3/15.
//  Copyright (c) 2015 Ingenico. All rights reserved.
//

#ifndef RBA_SDK_Bridging_Header_h_h
#define RBA_SDK_Bridging_Header_h_h

#import <RBA_SDK.h>

#endif