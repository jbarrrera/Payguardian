//
//  CardProcessorResult.h
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 03/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CardProcessorResultCode.h"
#import "CardType.h"
#import "XactTenderType.h"
@interface CardProcessorResult : NSObject
@property (nonatomic,strong) NSString *ResultText;
@property (nonatomic,strong) NSString *AuthCode;
@property (nonatomic,strong) NSString *RefNo;
@property (nonatomic,strong) NSNumber *ApprovedAmount;
@property (nonatomic,strong) NSNumber *OriginalAmount;
@property (nonatomic,strong) NSString *InvoiceNo;
@property (nonatomic,strong) NSString *MaskedCardNo;
@property (nonatomic,strong) NSDate *ExpiryDate;
@property (nonatomic,strong) NSString *Signature;
@property (nonatomic,strong) NSString *CountryCode;
@property (nonatomic,strong) NSString *CurrencyCode;
@property (nonatomic,assign) BOOL *IsCommercialCard;
@property (nonatomic,strong) NSString *HostCode;
@property (nonatomic,strong) NSString *HostResponse;
@property (nonatomic,strong) NSString *GatewayResult;
@property (nonatomic,strong) NSString *GatewayMessage;
@property (nonatomic,strong) NSString *InternalMessage;
@property (nonatomic,strong) NSString *Message;
@property (nonatomic,strong) NSString *RawResponse;
@property (nonatomic,strong) NSString *AvsResponse;
@property (nonatomic,strong) NSString *AvsMessage;
@property (nonatomic,strong) NSString *CvResponse;
@property (nonatomic,strong) NSString *CvMessage;
@property (nonatomic,strong) NSString *ChipCardAId;
@property (nonatomic,strong) NSString *EntryMethod;
@property (nonatomic,strong) NSString *AppLabel;
@end
CardProcessorResultCode Resultcode;
XactTenderType TenderType;
CardType CardType2;








