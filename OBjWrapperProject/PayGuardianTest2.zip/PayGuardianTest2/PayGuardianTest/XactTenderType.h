//
//  XactTenderType.h
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 03/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, XactTenderType) {
    Unknown2,            //
    
    /// <summary>
    /// Credit card.
    /// </summary>
    Credit,
    
    /// <summary>
    /// Debit card.
    /// </summary>
    Debit2,
    
    /// <summary>
    /// Check, to be processed as an eCheck.
    /// </summary>
    Check,
    
    /// <summary>
    /// EBT Food Stamp.
    /// </summary>
    EbtFood,
    
    /// <summary>
    /// EBT Cash Benefit.
    /// </summary>
    EbtCash,
    
    /// <summary>
    /// Gift card.
    /// </summary>
    Gift
    //-    Loyalty            // Loyalty Card; don't believe this is useful
};

