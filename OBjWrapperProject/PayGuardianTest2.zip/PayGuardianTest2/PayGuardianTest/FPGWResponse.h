//
//  FPGWResponse.h
//
//  Created by Alberto Aguilar on 2017/08/17.
//  Copyright © 2017. All rights reserved.
//

#import <Foundation/Foundation.h>

// NO, NO, NO!!!!!
// This (importing the PayGuardian SDK header here is RIDICULOUS.
//	We are trying to create a library with the slimmest possible
//	dependency on the PG SDK.
//#import <PayGuardian_SDK/PayGuardian_SDK.h>


// MAKE LIFE SIMPLE: Use strings for all data members.
//	WELL, will try and back off of that somewhat.

@interface FPGWResponse : NSObject

@property int		resultCode;
@property NSString	*resultText;

@property NSString	*authCode;
@property NSString	*maskedCardNo;
@property NSString	*cardType;
												//No Cash Back Amount?
@property NSString	*expireDate;

@property NSString	*isCommercialCard;
@property NSString	*refNo;
@property NSString	*approvedAmount;
@property NSString	*requestedAmt;
@property NSString	*remainingAmt;
@property NSString	*submittedAmt;
@property NSString	*tipAmt;
@property NSString	*remainingBalance;

// ExtData:
//		ReceiptData
@property NSString	*appLabel;
@property NSString	*chipCardAID;
@property NSString	*entryMethod;
@property NSString	*invoiceNo;

@property NSString	*gatewayMessage;
@property NSString	*internalMessage;
@property NSString	*message;
@property NSString	*responseTypeDesc;


//-(void) initWithResponseCode:(int) nResponseCode
-(void) fromPGResponseCode:(int) nResponseCode
				ResponseText:(NSString *) responseText
		   AuthorizationCode:(NSString *) AuthCode
				   MaskedPAN:(NSString *) MaskedPAN
					CardType:(NSString *) CardType
			  ExpirationDate:(NSString *) ExpireDate
			IsCommercialCard:(NSString *) IsCommCard
				ReferenceNum:(NSString *) RefNum
			AuthorizedAmount:(NSDecimalNumber *) AuthorizedAmt
			 RequestedAmount:(NSDecimalNumber *) RequestedAmt
			 RemainingAmount:(NSDecimalNumber *) RemainAmt
			 SubmittedAmount:(NSString *) SubmittedAmt
				   TipAmount:(NSString *) TipAmt
			  RemaingBalance:(NSString *) RemainBal
					AppLabel:(NSString *) AppLbl
				 ChipCardAID:(NSString *) AID
				 EntryMethod:(NSString *) EntryMeth
				  InvoiceNum:(NSString *) InvoiceNum
			  GatewayMessage:(NSString *) GatewayMsg
			 InternalMessage:(NSString *) InternalMsg
					 Message:(NSString *) msg
			ResponseTypeDesc:(NSString *) RespTypeDesc ;

/*
@property NSString *Transid;
@property NSString *RequestType;
@property int *ResponseCode;
@property NSString *ResponseDescription;
@property NSString *Token;
@property NSString *ExpirationDate;
@property NSString *AuthorizationCode;
@property NSString *OriginalReferenceNumber;
@property NSDecimalNumber *AuthorizedAmount;
@property NSDecimalNumber *OriginalAmount;
@property NSString *GatewayTransactionID;
@property NSString *GatewayMessage;
@property NSString *GatewayResult;
@property NSString *AVSMessage;
@property NSString *AVSResponse;
@property NSString *CVMessage;
@property NSString *CVResult;
@property NSString *InternalMessage;
@property NSString *TransactionCode;
@property NSString *TransactionDate;
@property NSDecimalNumber *RemainingAmount;
@property NSString * ISOCountryCode;
@property NSString * ISOCurrencyCode;
@property NSString * ISOTransactionDate;
@property NSString * ISORequestDate;
@property NSString * NetworkReferenceNumber;
@property NSString * NetworkCategoryCode;
@property NSString * NetworkMerchantId;
@property NSString *  NetworkTerminalId;
@property NSString * CardType;
@property NSString * MaskedPAN;
@property NSString * IsCommercialCard;
@property NSString * StreetMatchMessage;
@property NSString * SecondsRemaining;
@property NSString * MerchantCode;
@property NSString * MerchantAccountCode;
@property NSString * MerchantName;
@property NSString * ReceiptTagData;
@property NSString *IssuerTagData;
@property NSString * MaskedCardNumber;
@property NSString * ChipCardAID;
@property NSString * Invoice;
@property NSString * Seq;
@property NSString * EntryMethodv;
@property NSString *TotalAmount;
@property  NSString *AppLabel;
@property NSString *CardHolderName;
@property  NSString *NetworkMerchantID;
@property NSString *NetworkTerminalID;
@property NSString * CardFirstFour;
//the next fields are part of BridgeCommResponse coming from BPMpayment response
-(void) initWithTransactionId:(NSString * ) Transid
          RequestType:(NSString * ) RequestType
         ResponseCode:(int ) ResponseCode
  ResponseDescription:(NSString * ) ResponseDescription
                Token:(NSString * ) Token
       ExpirationDate:(NSString * ) ExpirationDate
    AuthorizationCode:(NSString * ) AuthorizationCode
OriginalReferenceNumber:(NSString * ) OriginalReferenceNumber
     AuthorizedAmount:(NSDecimalNumber * ) AuthorizedAmount
       OriginalAmount:(NSDecimalNumber * ) OriginalAmount
 GatewayTransactionID:(NSString * ) GatewayTransactionID
       GatewayMessage:(NSString * ) GatewayMessage
      InternalMessage:(NSString * ) InternalMessage
        GatewayResult:(NSString * ) GatewayResult
           AVSMessage:(NSString * ) AVSMessage
          AVSResponse:(NSString * ) AVSResponse
            CVMessage:(NSString * ) CVMessage
             CVResult:(NSString * ) CVResult
       GatewayMessage:(NSString * ) GatewayMessage
      InternalMessage:(NSString * ) InternalMessage
      TransactionCode:(NSString * ) TransactionCode
      TransactionDate:(NSString * ) TransactionDate
      RemainingAmount:(NSDecimalNumber * ) RemainingAmount
       ISOCountryCode:(NSString * ) ISOCountryCode
      ISOCurrencyCode:(NSString * ) ISOCurrencyCode
   ISOTransactionDate:(NSString * ) ISOTransactionDate
       ISORequestDate:(NSString * ) ISORequestDate
NetworkReferenceNumber:(NSString * ) NetworkReferenceNumber
  NetworkCategoryCode:(NSString * ) NetworkCategoryCode
    NetworkMerchantId:(NSString * ) NetworkMerchantId
    NetworkTerminalId:(NSString * ) NetworkTerminalId
             CardType:(NSString * ) CardType
            MaskedPAN:(NSString * ) MaskedPAN
     IsCommercialCard:(NSString * ) IsCommercialCard
   StreetMatchMessage:(NSString * ) StreetMatchMessage
     SecondsRemaining:(NSString * ) SecondsRemaining
         MerchantCode:(NSString * ) MerchantCode
  MerchantAccountCode:(NSString * ) MerchantAccountCode
         MerchantName:(NSString * ) MerchantName
       ReceiptTagData:(NSString * ) ReceiptTagData
        IssuerTagData:(NSString * ) IssuerTagData
// these fields are reserver for the future
//ApplicationIdentifier:(NSString * ) ApplicationIdentifier
//TerminalVerificationResults:(NSString * ) TerminalVerificationResults
//IssuerApplicationData:(NSString * ) IssuerApplicationData
//TransactionStatusInformation:(NSString * ) TransactionStatusInformation
//the next fields are part of BPNReceipt coming from BPMpayment response
     MaskedCardNumber:(NSString * ) MaskedCardNumber
          ChipCardAID:(NSString * ) ChipCardAID
              Invoice:(NSString * ) Invoice
                  Seq:(NSString * ) Seq
    AuthorizationCode:(NSString * ) AuthorizationCode
          EntryMethod:(NSString * ) EntryMethod
          TotalAmount:(NSString * ) TotalAmount
             AppLabel:(NSString * ) AppLabel
       CardHolderName:(NSString * ) CardHolderName
    NetworkMerchantID:(NSString * ) NetworkMerchantID
    NetworkTerminalID:(NSString * ) NetworkTerminalID
        CardFirstFour:(NSString * ) CardFirstFour
             CardType:(NSString * ) CardType;
*/

@end
