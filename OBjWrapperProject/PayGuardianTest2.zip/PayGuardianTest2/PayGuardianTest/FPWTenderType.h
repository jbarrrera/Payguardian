//
//  FPWTenderType.h
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 17/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FPWTenderType : NSObject

typedef enum {
    
    TENDER_TYPE_CREDIT,
    TENDER_TYPE_DEBIT,
    TENDER_TYPE_GIFT,
    TENDER_TYPE_LOYALTY
    
}TenderType;
@end
