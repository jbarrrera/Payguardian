//
//  CardProcessorResultCode.h
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 03/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#ifndef CardProcessorResultCode_h
#define CardProcessorResultCode_h


#endif /* CardProcessorResultCode_h */
typedef NS_ENUM(NSInteger, CardProcessorResultCode) {
    Approved,
    Cancelled,
    Declined,
    Error        // If this is possible
};
