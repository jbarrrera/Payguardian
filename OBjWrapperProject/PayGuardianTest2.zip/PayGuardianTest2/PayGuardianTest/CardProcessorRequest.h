//
//  CardProcessorRequest.h
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 03/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CardProcessorRequest : NSObject

@end
