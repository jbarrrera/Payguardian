//
//  CardProcessorExtentions.h
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 03/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//
#import <UIKit/UIKit.h>
#ifndef c_h
#define CardProcessorExtentions_h


#endif /* CardProcessorExtentions_h */
@interface CardProcessorExtentions : NSObject

@end
