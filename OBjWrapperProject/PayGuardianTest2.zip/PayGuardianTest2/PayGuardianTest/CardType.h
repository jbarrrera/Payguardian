//
//  CardType.h
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 03/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//


#import <Foundation/Foundation.h>

// although these are mapped to Fusion types, it is probably cleaner to come up with our own "modern"
// approach, and then map to Fusion "legacy" types instead when necessary. We already do this type
// of mapping in the Fusion API service for example.

/*\
 |*|    NOTE [SLS]:
 |*|                I am using the same ordering as in legacy Fusion for some of the enums,
 |*|                particularly CardType and XactType. I'm doing this because:
 |*|                    1.    Payment types are likely still setup with the current POS Admin, and
 |*|                    2.    The Acumatica ASI currently expects particular values in the CCTypeCode
 |*|                        column of the POSPmtType table (which comes from CardType).
 |*|                Note that some of the CardType members may never be used, but are here for
 |*|                    completeness, and to match the legacy implementation values.
 |*|                Note, also, that the enum CardType was polluted with 'Check' types.
 \*/
typedef NS_ENUM(NSInteger, CardType) {

    Amex,
    DinersClub,
    Visa,
    MasterCard,
    
    /// <summary>
    /// Discover credit card (originally known as Novus).
    /// </summary>
    Discover,
    
    Unknown,        // It's unfortunate that this was added in this position, rather
    //    than set to be -1 (or 0), in the first position. For certain, payment types
    //    defined in the POSPmtType table have CCTypeCode = -1 for types not represented here.
    //    In general, Fusion will set this in the request, expecting the CardProcessor interface
    //    to determine what card type was used. Somewhere in the response path, that card type
    //    must be translated to this Fusion enum.
    
    CarteBlanche,   // Unsure if this type is still encountered; in general, it probably is not.
    
    CheckDl,        // Check payment, with driver's license information (never sent to a CardProcessor interface).
    
    CheckAcct,      // Check payment, with check #, routing #, and account # information;
    //    may be sent to a CardProcessor interface if it supports 'eCheck' transactions.
    
    Debit,          // This is a holdover from the days when banks issued their own ATM cards, thus
    //    not labelled as Visa Debit, MasterCard Debit, etc. Likely no longer encountered.
    
    Jcb,            // Unsure if this type is still encountered.
    
    GiftLynk        // The first Gift Card processor supported by legacy Fusion; to my knowledge, no client
};
