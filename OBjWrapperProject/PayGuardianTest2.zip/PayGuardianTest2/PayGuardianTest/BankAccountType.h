//
//  BankAccountType.h
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 03/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#ifndef BankAccountType_h
#define BankAccountType_h

#endif /* BankAccountType_h */
typedef NS_ENUM(NSInteger, BankAccountType) {
    Checking,
    BusinessChecking,
    Savings
};
