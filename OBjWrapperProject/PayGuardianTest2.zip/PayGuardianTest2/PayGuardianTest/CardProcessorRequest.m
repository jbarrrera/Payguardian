//
//  CardProcessorRequest.m
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 03/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#import "CardProcessorRequest.h"
#import "XactTenderType.h"
#import "XactType.h"
@implementation CardProcessorRequest

@end
