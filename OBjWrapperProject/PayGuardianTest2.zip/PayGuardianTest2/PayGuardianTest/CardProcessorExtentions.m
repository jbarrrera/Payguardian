//
//  CardProcessorExtentions.m
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 03/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#import "CardProcessorExtentions.h"

@implementation CardProcessorExtentions


static NSString * CardTypesNames [12] = {@ "American Express", @ "Diner's Club", @ "VISA", @ "MasterCard", @ "Discover",
    @ "Unknown", @ "Carte Blanche", @ "Check-License", @ "Check-Account", @ "Debit",
    @ "JCB", @ "GiftLynk"
};


@end
