//
//  FPGWResponse.m
//
//  Created by Alberto Aguilar on 2017/08/17.
//  Copyright © 2017. All rights reserved.
//

#import "FPGWResponse.h"

@implementation FPGWResponse

//-(void) initWithResponseCode:(int) nResponseCode
-(void) fromPGResponseCode:(int) nResponseCode
				ResponseText:(NSString *) responseText
		   AuthorizationCode:(NSString *) AuthCode
				   MaskedPAN:(NSString *) MaskedPAN
					CardType:(NSString *) CardType
			  ExpirationDate:(NSString *) ExpireDate
			IsCommercialCard:(NSString *) IsCommCard
				ReferenceNum:(NSString *) RefNum
			AuthorizedAmount:(NSDecimalNumber *) AuthorizedAmt
			 RequestedAmount:(NSDecimalNumber *) RequestedAmt
			 RemainingAmount:(NSDecimalNumber *) RemainAmt
			 SubmittedAmount:(NSString *) SubmittedAmt
				   TipAmount:(NSString *) TipAmt
			  RemaingBalance:(NSString *) RemainBal
					AppLabel:(NSString *) AppLbl
				 ChipCardAID:(NSString *) AID
				 EntryMethod:(NSString *) EntryMeth
				  InvoiceNum:(NSString *) InvoiceNum
			  GatewayMessage:(NSString *) GatewayMsg
			 InternalMessage:(NSString *) InternalMsg
					 Message:(NSString *) msg
			ResponseTypeDesc:(NSString *) RespTypeDesc {
	
	_resultCode			= nResponseCode;
	_resultText			= responseText;
	_authCode			= AuthCode;
	_maskedCardNo		= MaskedPAN;
	_cardType			= CardType;
	_expireDate			= ExpireDate;
	_isCommercialCard	= IsCommCard;
	_refNo				= RefNum;
	_approvedAmount		= [NSString stringWithFormat:@"%@", AuthorizedAmt];
	_requestedAmt		= [NSString stringWithFormat:@"%@", RequestedAmt];
	_remainingAmt		= [NSString stringWithFormat:@"%@", RemainAmt];
	_submittedAmt		= SubmittedAmt;
	_tipAmt				= TipAmt;
	_remainingBalance	= RemainBal;
	_appLabel			= AppLbl;
	_chipCardAID		= AID;
	_entryMethod		= EntryMeth;
	_invoiceNo			= InvoiceNum;
	_gatewayMessage		= GatewayMsg;
	_internalMessage	= InternalMsg;
	_message			= msg;
	_responseTypeDesc	= RespTypeDesc;
}

@end
