//
//  FPGWtranType.m
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 17/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#import "FPGWtranType.h"

@implementation FPGWtranType

@end
