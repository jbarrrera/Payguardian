#import <UIKit/UIKit.h>
// NO, NO, NO!!!!!
//#import <PayGuardian_SDK/PayGuardian_SDK.h>
#include "FPGWrapper.h"


@interface ViewController : UIViewController

@property FPGWrapper	*frsWrapper;

// NO, NO, NO!!!!!
//@property BPNPaymentRequest *_request;
//@property PayGuardianTransaction *_transaction;
//@property RBAConnectionQueue *queue;

@end

