//
//  DoIt.h
//
//  Created by Manuel Acosta on 2017/08/17.
//  Copyright © 2017. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "FPGWrequest.h"
#include "FPGWResponse.h"


@interface DoIt : NSObject
{
	NSOperationQueue *opQueue;
}

@property (weak) FPGWRequest *frsRequest;
@property (weak) FPGWResponse *frsResponse;
@property BOOL result;


- (void) ProcessCardRequest:(FPGWRequest *) rq
				ResponsePtr:(FPGWResponse *) rp;
- (void) ProcessCardRequest;

// TODO: Convert FRS Tender/Transaction/Device/Industry Types to PG constants
// (NSString *) FrsTenderTypeCnv:(NSString *) frsType;
// (NSString *) FrsTranTypeCnv:(NSString *) frsType;
// (NSString *) FrsDeviceTypeCnv:(NSString *) frsType;
// (NSString *) FrsIndustryTypeCnv:(NSString *) frsType;


@end

/*
 pnRefNum:(NSString *)pnRefNum
 withAmount:(NSDecimalNumber *)amount
 withTipAmount:(NSDecimalNumber *)decimalAmount
 cashBackAmount:(NSDecimalNumber *)cashBackAmount
 tenderType:(NSString *) tenderType
 transactionType:(NSString *) transactionType
 username:(NSString *) username
 password:(NSString *) password
 merchantCode:(NSString *) merchantCode
 merchantAccountCode:(NSString *) merchantAccountCode
 paymentAccountNumber:(NSString *) paymentAccountNumber
 token:(NSString *) token
 expirationDate:(NSString *) expirationDate
 terminalType:(NSString *) terminalType
 industryType:(NSString *) industryType*/
