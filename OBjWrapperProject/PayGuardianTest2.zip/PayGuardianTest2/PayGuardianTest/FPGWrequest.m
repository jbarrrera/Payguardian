//
//  FPGWrequest.m
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 2017/08/17.
//  Copyright © 2017. All rights reserved.
//

#import "FPGWrequest.h"

@implementation FPGWRequest


-(void) initWithTenderType:(NSString *) tt
				  transactionType:(NSString *) xt
					invoiceNumber:(NSString *) invno
						  clerkId:(NSString*) ck
						regiserId:(NSString *) regId
						   amount:(NSString *) amt
						tipAmount:(NSString *) tipamt
				   cashBackAmount:(NSString *) cashbkamt
		  originalReferenceNumber:(NSString *) refno
						 username:(NSString *) usr
						 password:(NSString *) password
					 merchantCode:(NSString *) merchant
			  merchantAccountCode:(NSString *) merchacct
					   deviceType:(NSString *) devtype
						 testMode:(NSString *) test	{
	
    if ([super init]){
		_tendType		= tt;
		_tranType		= xt;
		_invcNo			= invno;
		_clerkID		= ck;
		_registerID		= regId;
        _amount			= amt;
        _tipAmount		= tipamt;
		_cashBackAmt	= cashbkamt;
		_refNo			= refno;
		_user			= usr;
		_pwd			= password;
		_merchCode		= merchant;
		_merchAcctCode	= merchacct;
		_deviceType		= devtype;
		_testMode		= test;
    };

}
/*
 -(void) initWithAmount:(NSDecimalNumber * ) amount
 tipAmount:(NSDecimalNumber *  ) tipAmount
 invoiceNumber:(NSString *) invoicenum
 tenderType:(NSString *) tendtype
 transactionType:(NSString * )transtype
 username:(NSString * )user
 password:(NSString * ) pass
 merchantCode:(NSString * ) mercode
 merchantAccountCode:(NSString * )meraccode
 originalReferenceNumber:(NSString * )refnumber
 connectionService:(NSObject<RBAConnectionService> *) conectservice
 connectionQueue:(RBAConnectionQueue * )conectqueue
 cashBackAmount:(NSDecimalNumber * )cashbank
 paymentAccountNumber:(NSString * )payaccount
 expirationDate:(NSString * )expdate
 shippingAddress:(BPNAddress * )shipadress
 deviceType:(NSString * ) devtype
 testMode:(BOOL) test
 withToken:(NSString * ) wtoken {
 */

@end
