#import "ViewController.h"
//#import "DoIt.h"
#import "FPGWrapper.h"

UITextView *textView;

@interface ViewController ()

@end

@implementation ViewController

//@synthesize _transaction;
//@synthesize _request;
////@synthesize queue;



- (void)viewDidLoad {
	[super viewDidLoad];
	
	textView = [[UITextView alloc] initWithFrame:CGRectMake(10, 10, 600, 600)];
	
	FPGWRequest * Requestinfo	= [[FPGWRequest alloc] init];
	
	// NOTE:  I'm getting PG crash when using our (Fusion) test merchant account
/*
	Requestinfo.tendType		= @"CREDIT";
	Requestinfo.tranType		= @"SALE";
	Requestinfo.amount			= @"7.00";
	Requestinfo.tipAmount		= @"0.00";
	Requestinfo.invcNo			= @"10101";
	Requestinfo.user			= @"fusiontest";	//@"paulpgtest";
	Requestinfo.pwd				= @"57!sE@3Fm";
	Requestinfo.merchCode		= @"205000";	//@"682000";
	Requestinfo.merchAcctCode	= @"205001";	//@"682001";
	Requestinfo.refNo			= @"";
	Requestinfo.cashBackAmt		= @"0.00";
	Requestinfo.deviceType		= @"rbabt";
	Requestinfo.testMode		= @"TRUE";
	Requestinfo.clerkID			= @"gwazoo";
	Requestinfo.registerID		= @"REG-01";
*/
	Requestinfo.tendType		= @"CREDIT";
	Requestinfo.tranType		= @"SALE";
	Requestinfo.amount			= @"7.00";
	Requestinfo.tipAmount		= @"0.00";
	Requestinfo.invcNo			= @"10101";
	Requestinfo.user			= @"paulpgtest";
	Requestinfo.pwd				= @"57!sE@3Fm";
	Requestinfo.merchCode		= @"682000";
	Requestinfo.merchAcctCode	= @"682001";
	Requestinfo.refNo			= @"";
	Requestinfo.cashBackAmt		= @"0.00";
	Requestinfo.deviceType		= @"rbabt";
	Requestinfo.testMode		= @"TRUE";
	Requestinfo.clerkID			= @"gwazoo";
	Requestinfo.registerID		= @"REG-01";
	
	FPGWResponse * Responseinfo = [[FPGWResponse alloc] init];
 
	FPGWrapper	*fw	= [[FPGWrapper alloc] init];
	
	[self.view addSubview:textView];
	
	[textView setText:@"test"];
	
//	DoIt *doIt = [DoIt alloc];
	
//	BOOL	bOk1	= [doIt ProcessCardRequest:Requestinfo ResponsePtr:Responseinfo];
//	BOOL	bOk2	= [doIt result];

	BOOL	bOk1	= [fw ProcessRequest:Requestinfo Response:Responseinfo];
//	BOOL	bOk2	= [fw result];
	
//	if( bOk1 )
	NSLog( @"==> Final result: %@", bOk1 ? @"SUCCESS" : @"FAIL" );
	
	
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}


/*
- (void)viewDidLoad {
    [super viewDidLoad];
	
FPGWrequest * Requestinfo;

Requestinfo.amount=[[NSDecimalNumber alloc] initWithString:@"5.00"] ;
Requestinfo.tipAmount=[[NSDecimalNumber alloc] initWithString:@"12.23"] ;
Requestinfo.invoicenum=@"10023";
Requestinfo.tendtype= TENDER_TYPE_CREDIT;
Requestinfo.transtype=TRANSACTION_TYPE_SALE;
Requestinfo.user=@"paulpgtest";
Requestinfo.pass=@"57!sE@3Fm";
Requestinfo.mercode=@"682000";
Requestinfo.meraccode=@"682000";
Requestinfo.refnumber=@"9987";
Requestinfo.cashbank=nil;
Requestinfo.payaccount=@"10023";
Requestinfo.devtype=TERMINAL_TYPE_INGENICO_BLUETOOTH ;
Requestinfo.expdate=nil;
Requestinfo.shipadress=nil;
Requestinfo.indtype=TRANSACTION_TYPE_SALE ;
Requestinfo.token=@"10023" ;
Requestinfo.indtype=TRANSACTION_TYPE_SALE;
Requestinfo.disableenv=NO;
Requestinfo.disableenv=YES;
	
FPGWResponse * Responseinfo = nil;
 
	
    textView = [[UITextView alloc] initWithFrame:CGRectMake(10, 10, 600, 600)];
	
    [self.view addSubview:textView];
	
    [textView setText:@"test"];
	
    DoIt *doIt = [DoIt alloc];
	
    [doIt withInvoiceNumber:@"10023" pnRefNum:@"9987" withAmount:[[NSDecimalNumber alloc] initWithString:@"5.00"] withTipAmount:[[NSDecimalNumber alloc] initWithString:@"12.23"] cashBackAmount:nil tenderType:TENDER_TYPE_CREDIT transactionType:TRANSACTION_TYPE_SALE username:@"paulpgtest" password:@"57!sE@3Fm" merchantCode:@"682000" merchantAccountCode:@"682001" paymentAccountNumber:@"10023" token:@"10023" expirationDate:nil terminalType:TERMINAL_TYPE_INGENICO_BLUETOOTH industryType:TRANSACTION_TYPE_SALE disableEmv:NO testMode:YES];
    BPNPayment *payment = [doIt returnPaymentObject];
    
    
     BOOL *Request =[[ProcessRequest alloc]
                               request:Requestinfo response:Responseinfo
                               ];
*/
    /* _request = [[BPNPaymentRequest alloc]
                initInvoiceNumber:@"1234"
                pnRefNum:nil
                amount:[NSDecimalNumber decimalNumberWithString:@"5.00"]
                tipAmount:[NSDecimalNumber decimalNumberWithString:@"1.00"]
                cashBackAmount:nil
                tenderType:TENDER_TYPE_CREDIT
                transactionType:TRANSACTION_TYPE_SALE
                username:@"paulpgtest"
                password:@"57!sE@3Fm"
                merchantCode:@"682000"
                merchantAccountCode:@"682001"
                paymentAccountNumber:nil
                token:nil
                expirationDate:nil
                terminalType:TERMINAL_TYPE_INGENICO_BLUETOOTH
                industryType:TRANSACTION_TYPE_SALE
                disableEmv:NO
                testMode:YES];*/
    
    
    /*
    _request = [[BPNPaymentRequest alloc] initWithAmount:[NSDecimalNumber decimalNumberWithString:@"5.00"]
                                               tipAmount:[NSDecimalNumber decimalNumberWithString:@"1.00"]
                                           invoiceNumber:@"1234"
                                              tenderType:TENDER_TYPE_CREDIT
                                         transactionType:TRANSACTION_TYPE_SALE
                                                username:@"paulpgtest"
                                                password:@"57!sE@3Fm"
                                            merchantCode:@"682000"
                                     merchantAccountCode:@"682001"
                                 originalReferenceNumber:nil
                                          cashBackAmount:nil
                                    paymentAccountNumber:nil
                                          expirationDate:nil
                                         shippingAddress:nil
                                              deviceType:TERMINAL_TYPE_INGENICO_BLUETOOTH
                                                testMode:YES
                                               withToken:nil
                                            industryType:TRANSACTION_INDUSTRY_TYPE_RESTAURANT];*/
/*
    _transaction = [[PayGuardianTransaction alloc] initWithPaymentRequest:_request];
    
    [_transaction runOnCompletion: ^(BPNPayment *payment, NSError *error) {
        //process response
        
        
    } onStateChanged: ^(PayGuardianTransactionState state) {
        //process state change
       
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
*/

@end
