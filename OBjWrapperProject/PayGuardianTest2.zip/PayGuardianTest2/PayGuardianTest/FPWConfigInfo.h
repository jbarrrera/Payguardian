//
//  FPWConfigInfo.h
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 16/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FPWConfigInfo : NSObject


@property (copy, nonatomic, nullable) NSString *mUserName;
@property (copy, nonatomic, nullable) NSString *mPassword;
@property (copy, nonatomic, nullable) NSString *mMerchCode;
@property (copy, nonatomic, nullable) NSString *mMerchAcctCode;
@property (copy, nonatomic, nullable) NSString *mServiceUrl;
@property BOOL mTestMode;
@property (copy, nonatomic, nullable) NSString *mDeviceType;

-(void) user:(NSString *_Nullable) us
pass:(NSString *_Nullable) pw
merchcode:(NSString *_Nullable) ma
merchact:(NSString *_Nullable) mc
mservice:(NSString *_Nullable) su
testmode:(NSString *_Nullable) tm
devtype:(NSString *_Nullable) rd;

@end
