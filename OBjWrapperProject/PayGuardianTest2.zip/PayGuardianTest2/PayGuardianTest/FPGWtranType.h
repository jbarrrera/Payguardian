//
//  FPGWtranType.h
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 17/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FPGWtranType : NSObject
typedef enum {
        TRANSACTION_TYPE_SALE,// Makes a purchase with a credit card, debitcard, gift card, or loyalty card.T
        TRANSACTION_TYPE_SALE_AUTH,//: Verifies/authorizes a payment amount on a credit card.
        TRANSACTION_TYPE_REFUND, // Returns a creditcard ordebitcardpayment.
        TRANSACTION_TYPE_VOID,// Removes a creditcardtransaction from an unsettled batch.
        TRANSACTION_TYPE_CAPTURE
    
}TranType;
@end
