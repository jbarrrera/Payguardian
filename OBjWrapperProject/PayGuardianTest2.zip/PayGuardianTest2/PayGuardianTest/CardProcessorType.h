//
//  CardProcessorType.h
//  PayGuardianTest
//
//  Created by Alberto Aguilar on 03/08/17.
//  Copyright © 2017 Paul Roberts. All rights reserved.
//

#ifndef CardProcessorType_h
#define CardProcessorType_h


#endif /* CardProcessorType_h */
typedef NS_ENUM(NSInteger, CardProcessorType) {
    Demo,
    PayGuardian
};
