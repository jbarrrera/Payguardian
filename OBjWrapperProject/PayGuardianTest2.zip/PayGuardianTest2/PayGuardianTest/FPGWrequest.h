//
//  FPGWrequest.h
//
//  Created by Alberto Aguilar on 2017/08/17.
//  Copyright © 2017. All rights reserved.
//

#import <Foundation/Foundation.h>

// This (importing the PayGuardian SDK header here is RIDICULOUS.
//	We are trying to create a library with the slimmest possible
//	dependency on the PG SDK.
// There's no wonder that the Xamarin binding was insisting on
//	bringing in PG symbols, which would be the only way that
//	Xamarin would give dulicate symbol errors for PG symbols.
//#import <PayGuardian_SDK/PayGuardian_SDK.h>


// MAKE LIFE SIMPLE: Use strings for all data members.

@interface FPGWRequest : NSObject

@property NSString	*tendType;
@property NSString	*tranType;
@property NSString	*amount;
@property NSString	*tipAmount;
@property NSString	*invcNo;
@property NSString	*user;
@property NSString	*pwd;
@property NSString	*merchCode;
@property NSString	*merchAcctCode;
@property NSString	*refNo;
@property NSString	*cashBackAmt;
@property NSString	*deviceType;	// type of card reader
// ###################################################################
// NOTE: We currently have no provision for setting Industry Type.
//			Windows Desktop PG did not require it, or maybe it was
//			setup in the PG app. Authorize.NET does require it, and
//			it is a setting in PG iOS paymebnt request.
//		 We will address this later.
//@property NSString * indtype;
// ###################################################################
//@property BOOL disableenv;	=> Don't believe we have any messing this.
@property NSString	*testMode;
//@property NSString *token;	=> We currently do not use this
@property NSString	*clerkID;
@property NSString	*registerID;
//@property NSString	*partialAuth;	// Allow partial authorization. ["TRUE"/"FALSE"]

-(void) initWithTenderType:(NSString *) tt
				  transactionType:(NSString *) xt
					invoiceNumber:(NSString *) invno
						  clerkId:(NSString*) ck
						regiserId:(NSString *) regId
						   amount:(NSString *) amt
						tipAmount:(NSString *) tipamt
				   cashBackAmount:(NSString *) cashbkamt
		  originalReferenceNumber:(NSString *) refno
						 username:(NSString *) usr
						 password:(NSString *) password
					 merchantCode:(NSString *) merchant
			  merchantAccountCode:(NSString *) merchacct
					   deviceType:(NSString *) devtype
						 testMode:(NSString *) test ;

/*
 @property NSDecimalNumber *amount;
 @property NSDecimalNumber *tipAmount;
 @property NSString *invoicenum;
 @property NSString *tendtype;
 @property NSString *transtype;
 @property NSString *user;
 @property NSString *pass;
 @property NSString *mercode;
 @property NSString *meraccode;
 @property NSString *refnumber;
 @property NSObject<RBAConnectionService> * conectservice;
 @property RBAConnectionQueue * conectqueue;
 @property NSDecimalNumber *cashbank;
 @property NSString *payaccount;
 @property NSString *expdate;
 @property BPNAddress * shipadress;
 @property NSString * devtype;
 @property NSString * indtype;
 @property BOOL disableenv;
 @property BOOL test;
 @property NSString *token;
 
 -(void) initWithAmount:(NSDecimalNumber * ) amount
 tipAmount:(NSDecimalNumber *  ) tipAmount
 invoiceNumber:(NSString *) invoicenum
 tenderType:(NSString *) tendtype
 transactionType:(NSString * )transtype
 username:(NSString * )user
 password:(NSString * ) pass
 merchantCode:(NSString * ) mercode
 merchantAccountCode:(NSString * )meraccode
 originalReferenceNumber:(NSString * )refnumber
 //connectionService:(NSObject<RBAConnectionService> *) conectservice
 //connectionQueue:(RBAConnectionQueue * )conectqueue
 cashBackAmount:(NSDecimalNumber * )cashbank
 paymentAccountNumber:(NSString * )payaccount	// Manual entry unsupported in Fusion
 expirationDate:(NSString * )expdate			// Manual entry unsupported in Fusion
 //shippingAddress:(BPNAddress * )shipadress
 deviceType:(NSString * ) devtype
 deviceType:(NSString * ) indtype
 deviceType:(BOOL) devtype
 testMode:(BOOL) test
 withToken:(NSString * ) token ;
 */

@end


